import React, { useState } from 'react';
import {
  ShieldCheck,
  Wrench,
  Truck,
  Award,
  Clock,
  MapPin,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  PhoneCall,
  HardHat,
  Zap,
  Flame,
  FileText,
  ChevronRight,
  Sparkles,
  Layers,
  Building,
  Fuel,
  Users,
  CheckCircle2,
  Calendar,
  Send,
  Phone,
  Mail,
  ExternalLink,
  LifeBuoy
} from 'lucide-react';
import { CMSContent, ServiceCategory, PetrolPump, User } from '../types';
import { BPWLogo } from './brand/BPWLogo';
import { BPW_BRAND_CONSTANTS } from './brand';
import { AboutHeroSection } from './home/AboutHeroSection';
import { OurServicesSection } from './home/OurServicesSection';
import { WorkProcessSection } from './home/WorkProcessSection';
import { IndustriesSection } from './home/IndustriesSection';
import { CoreServicesSection } from './home/CoreServicesSection';
import { CivilWorksPage } from './services/CivilWorksPage';
import { HistoryModal } from './home/HistoryModal';
import { ContactModal } from './home/ContactModal';

export interface PublicWebsiteProps {
  cms: CMSContent;
  categories: ServiceCategory[];
  pumps?: PetrolPump[];
  currentUser?: User;
  onRequestService?: (req: any) => Promise<any>;
  onNavigate?: (view: string, extra?: any) => void;
  onOpenAudit: () => void;
  onOpenAI: () => void;
  onOpenAuth?: (portal: any) => void;
}

export const PublicWebsite: React.FC<PublicWebsiteProps> = ({
  cms,
  categories,
  pumps = [],
  currentUser,
  onRequestService,
  onNavigate,
  onOpenAudit,
  onOpenAI,
  onOpenAuth
}) => {
  const [subView, setSubView] = useState<string | null>(null);
  // Direct Quick Inquiry State
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryPump, setInquiryPump] = useState('');
  const [inquiryCategory, setInquiryCategory] = useState(categories[0]?.name || 'Mechanical Works');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [inquirySubmitted, setInquirySubmitted] = useState(false);

  // Emergency Breakdown State
  const [emergencyPumpName, setEmergencyPumpName] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [emergencyLocation, setEmergencyLocation] = useState('');
  const [emergencyIssue, setEmergencyIssue] = useState('Dispenser Hydraulic Lock / Delivery Motor Failure');
  const [emergencySubmitted, setEmergencySubmitted] = useState(false);

  // Home Page Modals
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);

  const navigateTo = (view: string, extra?: any) => {
    if (onNavigate) {
      onNavigate(view, extra);
    }
  };

  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryPhone.trim()) return;

    if (onRequestService) {
      await onRequestService({
        clientId: currentUser?.id || 'usr-client-1',
        clientName: inquiryName || currentUser?.name || 'Inquiry Contact',
        pumpId: pumps[0]?.id || 'pmp-101',
        pumpName: inquiryPump || 'Forecourt Fuel Station',
        categoryId: 'cat-mech',
        categoryName: inquiryCategory,
        title: `Public Inquiry: ${inquiryCategory}`,
        description: inquiryMessage || 'Requested consultation and site visit via public portal.',
        priority: 'MEDIUM',
        status: 'NEW',
        assignedEngineerId: null,
        assignedEngineerName: null,
        assignedVanId: null,
        estimatedCost: 8500,
        finalCost: null,
        scheduledDate: new Date().toISOString().split('T')[0],
        completedDate: null,
        lotoApplied: false,
        zeroLelConfirmed: false,
        partsUsed: [],
        technicianNotes: null,
        customerRating: null
      });
    }

    setInquirySubmitted(true);
    setTimeout(() => {
      setInquirySubmitted(false);
      setInquiryName('');
      setInquiryPhone('');
      setInquiryPump('');
      setInquiryMessage('');
    }, 4000);
  };

  const handleEmergencySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emergencyPhone.trim()) return;

    if (onRequestService) {
      await onRequestService({
        clientId: currentUser?.id || 'usr-client-1',
        clientName: 'Forecourt Station Emergency Desk',
        pumpId: pumps[0]?.id || 'pmp-101',
        pumpName: emergencyPumpName || 'Highway Retail Outlet',
        categoryId: 'cat-disp',
        categoryName: 'Dispenser & Hydraulics',
        title: `EMERGENCY 45-MIN BREAKDOWN: ${emergencyIssue}`,
        description: `Rapid emergency dispatch requested for ${emergencyLocation || 'Forecourt site'}. Contact: ${emergencyPhone}. Issue: ${emergencyIssue}`,
        priority: 'EMERGENCY',
        status: 'NEW',
        assignedEngineerId: null,
        assignedEngineerName: null,
        assignedVanId: null,
        estimatedCost: 12500,
        finalCost: null,
        scheduledDate: new Date().toISOString().split('T')[0],
        completedDate: null,
        lotoApplied: false,
        zeroLelConfirmed: false,
        partsUsed: [],
        technicianNotes: null,
        customerRating: null
      });
    }

    setEmergencySubmitted(true);
    setTimeout(() => {
      setEmergencySubmitted(false);
      setEmergencyPumpName('');
      setEmergencyPhone('');
      setEmergencyLocation('');
    }, 5000);
  };


  return (
    <div className="bg-white text-[#0F2B48]">
      {subView === 'civil' && <CivilWorksPage />}
      {subView === null && (
        <>
          {/* 1. ABOUT US HERO SECTION */}
          <AboutHeroSection
            onOpenHistory={() => setShowHistoryModal(true)}
            onOpenContact={() => setShowContactModal(true)}
          />

          {/* 2. OUR SERVICES SECTION */}
          <OurServicesSection
            onSelectService={(serviceTitle) => {
              if (serviceTitle === 'Civil Works') {
                setSubView('civil');
              } else {
                setInquiryCategory(serviceTitle);
                const el = document.getElementById('quick-booking-desk');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          />

          {/* 3. WORK PROCESS SECTION */}
          <WorkProcessSection />

          {/* 4. INDUSTRIES WE SERVE SECTION */}
          <IndustriesSection />

          {/* 5. OUR CORE SERVICES SECTION */}
          <CoreServicesSection />

          {/* CENTRAL DISPATCH & SERVICE BOOKING DESK */}
          <section id="quick-booking-desk" className="py-16 sm:py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Info */}
            <div className="lg:col-span-7 space-y-5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100 text-[#0F2B48] text-xs font-bold border border-amber-300">
                <ShieldCheck className="w-4 h-4 text-[#E55812]" />
                <span>Bharat PetroWork National Dispatch & Helpdesk</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F2B48] tracking-tight">
                Schedule Engineering Inspection or Site Service
              </h2>
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                Connect directly with our central engineering operations desk. Whether you need fuel dispenser repair, tank calibration, canopy fabrication, or a comprehensive site audit, our certified petroleum engineers are deployed across major industrial corridors and highway networks.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
                  <div className="text-xs font-bold text-[#E55812]">24/7 Hotline</div>
                  <div className="text-xs font-mono font-bold text-slate-800 mt-0.5">1800-PETRO-WORK</div>
                </div>
                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
                  <div className="text-xs font-bold text-[#E55812]">Mobile Service Vans</div>
                  <div className="text-xs font-bold text-slate-800 mt-0.5">GPS Monitored Fleet</div>
                </div>
                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
                  <div className="text-xs font-bold text-[#E55812]">Compliance</div>
                  <div className="text-xs font-bold text-slate-800 mt-0.5">PESO & OISD-141</div>
                </div>
              </div>
            </div>

            {/* Right Booking Form */}
            <div className="lg:col-span-5">
              <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xl relative">
                <div className="absolute -top-3.5 right-6 bg-[#E55812] text-white text-[11px] font-extrabold px-3.5 py-1 rounded-full uppercase tracking-wider shadow-md">
                  Central Helpdesk
                </div>

                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 text-[#0F2B48] flex items-center justify-center font-bold">
                    <Truck className="w-6 h-6 text-[#E55812]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-extrabold text-[#0F2B48]">Request Station Service</h3>
                    <p className="text-xs text-slate-500">Direct booking with Bharat PetroWork Dispatch</p>
                  </div>
                </div>

                {inquirySubmitted ? (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center text-emerald-800 space-y-2">
                    <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
                    <h4 className="font-extrabold text-base">Service Request Registered!</h4>
                    <p className="text-xs text-emerald-700 leading-relaxed">
                      Your ticket has been recorded in the central dispatcher queue. Our area field supervisor will contact you within 15 minutes.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleInquirySubmit} className="space-y-3.5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Your Name / Station Manager *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Ramesh Chandra"
                        value={inquiryName}
                        onChange={e => setInquiryName(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0F2B48] text-slate-900"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Contact *</label>
                        <input
                          type="tel"
                          required
                          placeholder="+91 98765 43210"
                          value={inquiryPhone}
                          onChange={e => setInquiryPhone(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0F2B48] text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Retail Outlet (RO) / City</label>
                        <input
                          type="text"
                          placeholder="e.g. IOCL Hub Noida"
                          value={inquiryPump}
                          onChange={e => setInquiryPump(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0F2B48] text-slate-900"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Service Requirement</label>
                      <select
                        value={inquiryCategory}
                        onChange={e => setInquiryCategory(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0F2B48] bg-white text-slate-900"
                      >
                        <option>Civil Works</option>
                        <option>Mechanical Works</option>
                        <option>Electrical Works</option>
                        <option>Fire & Safety Systems</option>
                        <option>Operation & Maintenance (O&M)</option>
                        <option>Tank Rehabilitation Work Services</option>
                        <option>Pipeline Maintenance & Repair</option>
                        <option>Fuel Dispenser Services</option>
                        <option>Mobile Service Van Support</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Brief Description of Work</label>
                      <textarea
                        rows={2}
                        placeholder="Provide details about symptoms, equipment model, or scope..."
                        value={inquiryMessage}
                        onChange={e => setInquiryMessage(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0F2B48] text-slate-900"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-[#E55812] hover:bg-[#D9480F] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition transform hover:-translate-y-0.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Service Request</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. PUMP MITRA ECOSYSTEM CONNECTIVITY */}
      <section className="py-20 bg-gradient-to-b from-slate-50 to-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                PUMP MITRA DIGITAL PLATFORM
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F2B48] tracking-tight">
                Smart Infrastructure Maintenance for Petrol Pump Owners
              </h2>

              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                Pump Mitra is Bharat PetroWork's dedicated digital platform connecting petrol pump owners, certified petroleum engineers, and infrastructure companies. It provides seamless management of fuel stations:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {[
                  { title: 'Tank Cleaning & Testing', desc: 'Book ultrasonic tests, sludge suction, and water ingress checks.' },
                  { title: 'Pipeline Installation', desc: 'Monitor electrofusion double-wall HDPE line installations.' },
                  { title: 'Leak Detection', desc: 'Automated sensor diagnostics and zero LEL vapor scanning.' },
                  { title: 'Dispenser Repair', desc: 'Nozzle calibration, pulser repair, and motor replacements.' },
                  { title: 'AMC Maintenance', desc: 'Scheduled quarterly preventive servicing with SLA tracking.' },
                  { title: 'Automation Systems', desc: 'IoT ATG level integration and forecourt POS connectivity.' }
                ].map((item, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-sm">
                    <div className="font-bold text-xs text-[#0F2B48]">{item.title}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{item.desc}</div>
                  </div>
                ))}
              </div>

              <div className="pt-2">
                <button
                  onClick={() => navigateTo('pump-mitra')}
                  className="px-6 py-3.5 rounded-xl bg-[#0F2B48] hover:bg-[#1A4068] text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <span>Enter Pump Mitra Portal</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="bg-[#0F2B48] text-white rounded-3xl p-8 shadow-2xl relative">
                <div className="flex items-center justify-between pb-4 border-b border-white/15">
                  <BPWLogo variant="dark-bg" size="sm" subBrand="pump-mitra" />
                  <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                    LIVE ECOSYSTEM
                  </span>
                </div>

                <div className="mt-6 space-y-4">
                  <div className="p-4 rounded-xl bg-white/10 border border-white/10">
                    <div className="text-xs text-slate-400">Step 1: Station Owner</div>
                    <div className="font-bold text-sm text-white mt-0.5">Dealer logs ticket on Pump Mitra app</div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/10 border border-white/10">
                    <div className="text-xs text-slate-400">Step 2: Central Control</div>
                    <div className="font-bold text-sm text-amber-300 mt-0.5">Admin assigns certified Field Engineer & Mobile Van</div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/10 border border-white/10">
                    <div className="text-xs text-slate-400">Step 3: On-Site Execution</div>
                    <div className="font-bold text-sm text-white mt-0.5">Engineer performs LOTO, parts replacement, and digital sign-off</div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/10 border border-white/10">
                    <div className="text-xs text-slate-400">Step 4: Real-time Settlement</div>
                    <div className="font-bold text-sm text-emerald-300 mt-0.5">Invoice generated with GST, auto inventory deduction, ticket closed</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 9. EMERGENCY BREAKDOWN SECTION (45-MIN SLA) */}
      <section id="emergency-section" className="py-20 bg-red-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold">
                <AlertTriangle className="w-4 h-4 text-amber-300" />
                24/7 FORECOURT HAZMAT & EMERGENCY SLA
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
                45-Minute Emergency Breakdown Rapid Dispatch
              </h2>
              <p className="text-red-100 text-sm leading-relaxed">
                A fuel dispenser breakdown, hydraulic failure, shear valve trip, or vapor leak immediately halts station revenue. Our rapid mobile response units are equipped with flameproof safety tools, spare parts, and certified petroleum technicians for immediate dispatch.
              </p>
              <div className="flex items-center gap-4 text-xs font-bold pt-2">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-amber-300" />
                  <span>Immediate Escalation: +91 85270 23022 / 1800-890-BPWORK</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-300" />
                  <span>Average Arrival: 38 Mins</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 bg-white text-[#0F2B48] rounded-3xl p-6 sm:p-8 shadow-2xl">
              {emergencySubmitted ? (
                <div className="text-center py-6 space-y-3">
                  <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-extrabold text-red-700">EMERGENCY DISPATCH INITIATED!</h3>
                  <p className="text-xs text-slate-600">
                    The nearest Bharat PetroWork service van has been notified with your coordinates. Keep your phone line active for immediate dispatch confirmation.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleEmergencySubmit} className="space-y-3">
                  <div className="font-extrabold text-base text-[#0F2B48] mb-1">
                    Instant Forecourt Emergency Dispatch
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Station / RO Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Highway Fuel Center RO-10492"
                      value={emergencyPumpName}
                      onChange={e => setEmergencyPumpName(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 text-slate-900 focus:ring-2 focus:ring-red-600"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Emergency Phone *</label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 98112 34567"
                        value={emergencyPhone}
                        onChange={e => setEmergencyPhone(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 text-slate-900 focus:ring-2 focus:ring-red-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Site Location / Highway</label>
                      <input
                        type="text"
                        placeholder="e.g. NH-24 Km 42"
                        value={emergencyLocation}
                        onChange={e => setEmergencyLocation(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 text-slate-900 focus:ring-2 focus:ring-red-600"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Emergency Incident Nature</label>
                    <select
                      value={emergencyIssue}
                      onChange={e => setEmergencyIssue(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 text-slate-900 focus:ring-2 focus:ring-red-600 bg-white"
                    >
                      <option>Dispenser Hydraulic Lock / Motor Failure</option>
                      <option>Underground Pipe Vapor Leakage / Pressure Drop</option>
                      <option>Submersible Turbine Pump (STP) Trip</option>
                      <option>Shear Valve Impact / Fuel Shutoff</option>
                      <option>Flameproof Electrical Tripping / Flash Alert</option>
                    </select>
                  </div>
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                  >
                    <AlertTriangle className="w-4 h-4 text-white" />
                    <span>DISPATCH EMERGENCY VAN NOW</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 10. CONTACT US SECTION */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-blue-100 text-[#0F2B48] text-xs font-bold">
                GET IN TOUCH
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F2B48] tracking-tight">
                Connect with Bharat PetroWork Central Technical Desk
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed font-normal">
                Whether you require turnkey petrol pump development, underground tank rehabilitation, emergency repair, or AMC coverage, our technical directors and field engineers are ready to assist.
              </p>

              <div className="space-y-4 pt-2">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-[#0F2B48] flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-[#E55812]" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-[#0F2B48]">Corporate Headquarters</div>
                    <div className="text-xs text-slate-600 mt-0.5">{BPW_BRAND_CONSTANTS.headquarters}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-[#0F2B48] flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5 text-[#E55812]" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-[#0F2B48]">24/7 National Helpdesk</div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      Toll-Free: {BPW_BRAND_CONSTANTS.tollFree} | Mobile: {BPW_BRAND_CONSTANTS.supportHotline}
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-[#0F2B48] flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5 text-[#E55812]" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-[#0F2B48]">Email Inquiries</div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {BPW_BRAND_CONSTANTS.email} | {BPW_BRAND_CONSTANTS.infoEmail}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-3xl p-8">
              <h3 className="text-lg font-extrabold text-[#0F2B48] mb-4">Send a Direct Message / RFQ</h3>
              <form onSubmit={handleInquirySubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Your name"
                      value={inquiryName}
                      onChange={e => setInquiryName(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 bg-white text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={inquiryPhone}
                      onChange={e => setInquiryPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 bg-white text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Message or Project Scope</label>
                  <textarea
                    rows={4}
                    placeholder="Describe your site details, fuel station location, equipment requirements..."
                    value={inquiryMessage}
                    onChange={e => setInquiryMessage(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 bg-white text-slate-900"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-[#0F2B48] hover:bg-[#1A4068] text-white font-bold text-xs flex items-center gap-2 shadow transition cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Message to Bharat PetroWork</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* 11. CORPORATE FOOTER */}
      <footer className="bg-[#0A1C30] text-slate-300 py-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
            {/* Brand column */}
            <div className="lg:col-span-2 space-y-4">
              <BPWLogo variant="dark-bg" size="lg" showTagline={true} />
              <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
                Bharat PetroWork is India’s dedicated petroleum engineering and infrastructure ecosystem, developing fuel stations, executing underground tank rehabilitation, and ensuring uninterrupted forecourt uptime.
              </p>
              <div className="text-[11px] font-mono text-slate-400 space-y-0.5">
                <div>GSTIN: {BPW_BRAND_CONSTANTS.gstin}</div>
                <div>CIN: {BPW_BRAND_CONSTANTS.cin}</div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <div className="text-xs font-extrabold text-white uppercase tracking-wider mb-4">Portals</div>
              <ul className="space-y-2 text-xs">
                <li>
                  <button onClick={() => navigateTo('pump-mitra')} className="hover:text-amber-400 transition cursor-pointer">
                    Pump Mitra Portal
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo('engineer')} className="hover:text-amber-400 transition cursor-pointer">
                    Field Engineer App
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo('e-market')} className="hover:text-amber-400 transition cursor-pointer">
                    E-Marketplace
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo('academy')} className="hover:text-amber-400 transition cursor-pointer">
                    BPW Technical Academy
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo('jobs')} className="hover:text-amber-400 transition cursor-pointer">
                    Jobs & Career
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo('admin-crm')} className="hover:text-amber-400 transition cursor-pointer">
                    Operations Control Center
                  </button>
                </li>
              </ul>
            </div>

            {/* Services */}
            <div>
              <div className="text-xs font-extrabold text-white uppercase tracking-wider mb-4">Services</div>
              <ul className="space-y-2 text-xs">
                <li>Tank Rehabilitation Systems</li>
                <li>Civil Driveways & Canopies</li>
                <li>Electrofusion HDPE Piping</li>
                <li>Dispenser Erection & Calibration</li>
                <li>Flameproof Electrical Zone-1</li>
                <li>OISD-141 Safety Compliance</li>
              </ul>
            </div>

            {/* Compliance & Emergency */}
            <div>
              <div className="text-xs font-extrabold text-white uppercase tracking-wider mb-4">Emergency & Trust</div>
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-red-200">
                  <div className="font-bold text-[11px] text-red-300">24/7 HazMat Response:</div>
                  <div className="font-mono font-bold mt-0.5">+91 85270 23022 / 1800-890-BPWORK</div>
                </div>
                <div className="text-[11px] text-slate-400">
                  Certified: ISO 9001:2015, PESO Approved, OISD Compliant.
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <div>
              © {new Date().getFullYear()} {BPW_BRAND_CONSTANTS.legalName}. All rights reserved.
            </div>
            <div className="flex items-center gap-6">
              <span>Privacy Policy</span>
              <span>Terms of Service</span>
              <span>Statutory Compliance</span>
            </div>
          </div>
        </div>
      </footer>

      {/* History Modal */}
      <HistoryModal
        isOpen={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
      />

      {/* Contact Modal */}
      <ContactModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
        onSubmitInquiry={onRequestService}
      />
        </>
      )}
    </div>
  );
};
