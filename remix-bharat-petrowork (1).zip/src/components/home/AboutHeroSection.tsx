import React from 'react';
import onsiteEngineeringImg from '../../assets/images/onsite_engineering_1789940636334.jpg';
import projectPlanningImg from '../../assets/images/project_planning_1789940651557.jpg';
import qualityInspectImg from '../../assets/images/quality_inspect_1789940663308.jpg';

interface AboutHeroSectionProps {
  onOpenHistory?: () => void;
  onOpenContact?: () => void;
}

export const AboutHeroSection: React.FC<AboutHeroSectionProps> = ({
  onOpenHistory,
  onOpenContact
}) => {
  return (
    <section id="about-hero" className="relative bg-white pt-10 pb-16 sm:pt-14 sm:pb-20 overflow-hidden">
      {/* Background soft geometric wave decor matching mockup */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-50/60 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-orange-50/40 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Text & Stats */}
          <div className="lg:col-span-6 space-y-6">
            {/* Pill Badge */}
            <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-white border border-amber-200/80 shadow-sm text-[11px] font-extrabold tracking-wider text-[#E55812] uppercase">
              ABOUT BHARAT PETROWORK
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-[54px] font-extrabold text-[#0F2B48] tracking-tight leading-[1.12]">
              Building Modern <span className="text-[#E55812]">Fuel Stations</span> Across India
            </h1>

            {/* Descriptive Copy */}
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed font-normal">
              Bharat Petrowork is a trusted infrastructure and engineering services company specializing in the development of petrol pumps and fuel stations across India. We provide complete end-to-end solutions including construction, installation, maintenance, fuel pipeline systems, canopy structures, electrical works, automation systems, and fuel station modernization. With a strong focus on quality, safety, and timely execution, we deliver reliable petroleum infrastructure solutions that meet industry standards and ensure long-term operational performance.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-1">
              <button
                type="button"
                onClick={onOpenHistory}
                className="px-8 py-3.5 rounded-full bg-[#E55812] hover:bg-[#D9480F] text-white font-bold text-sm shadow-md shadow-[#E55812]/25 transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                Our History
              </button>

              <button
                type="button"
                onClick={onOpenContact}
                className="px-8 py-3.5 rounded-full bg-white hover:bg-slate-50 text-[#0F2B48] font-bold text-sm border border-slate-200 shadow-sm transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                Contact Us
              </button>
            </div>

            {/* 3 Metric Stat Cards */}
            <div className="grid grid-cols-3 gap-3 sm:gap-4 pt-4">
              <div className="bg-white rounded-2xl border border-slate-100 p-4 sm:p-5 shadow-sm text-center sm:text-left transition hover:border-amber-200">
                <div className="text-2xl sm:text-3xl font-extrabold text-[#E55812] font-mono leading-none">
                  100+
                </div>
                <div className="text-xs sm:text-sm font-semibold text-slate-600 mt-2">
                  Projects
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-100 p-4 sm:p-5 shadow-sm text-center sm:text-left transition hover:border-amber-200">
                <div className="text-2xl sm:text-3xl font-extrabold text-[#E55812] font-mono leading-none">
                  24/7
                </div>
                <div className="text-xs sm:text-sm font-semibold text-slate-600 mt-2">
                  Support
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-100 p-4 sm:p-5 shadow-sm text-center sm:text-left transition hover:border-amber-200">
                <div className="text-2xl sm:text-3xl font-extrabold text-[#E55812] font-mono leading-none">
                  10+
                </div>
                <div className="text-xs sm:text-sm font-semibold text-slate-600 mt-2">
                  Experience
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Photo Collage */}
          <div className="lg:col-span-6 space-y-4">
            {/* Top Large Photo: On-Site Engineering */}
            <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden shadow-lg border border-slate-100 group">
              <img
                src={onsiteEngineeringImg}
                alt="On-Site Engineering"
                className="w-full h-56 sm:h-72 object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-4 left-4">
                <span className="inline-block px-3.5 py-1.5 rounded-full bg-white/95 backdrop-blur-sm text-[#0F2B48] text-xs font-bold shadow-md">
                  On-Site Engineering
                </span>
              </div>
            </div>

            {/* Bottom Two Photos: Project Planning & Quality Inspection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="relative rounded-2xl overflow-hidden shadow-md border border-slate-100 group">
                <img
                  src={projectPlanningImg}
                  alt="Project Planning"
                  className="w-full h-44 sm:h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-3 left-3">
                  <span className="inline-block px-3 py-1 rounded-full bg-white/95 backdrop-blur-sm text-[#0F2B48] text-[11px] font-bold shadow-md">
                    Project Planning
                  </span>
                </div>
              </div>

              <div className="relative rounded-2xl overflow-hidden shadow-md border border-slate-100 group">
                <img
                  src={qualityInspectImg}
                  alt="Quality Inspection"
                  className="w-full h-44 sm:h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-3 left-3">
                  <span className="inline-block px-3 py-1 rounded-full bg-white/95 backdrop-blur-sm text-[#0F2B48] text-[11px] font-bold shadow-md">
                    Quality Inspection
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
