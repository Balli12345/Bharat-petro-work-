import React, { useState } from 'react';
import { X, Phone, Mail, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { BPWLogo } from '../brand/BPWLogo';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitInquiry?: (data: any) => Promise<any>;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  isOpen,
  onClose,
  onSubmitInquiry
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [roLocation, setRoLocation] = useState('');
  const [requirement, setRequirement] = useState('New Petrol Pump Infrastructure Development');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) return;

    if (onSubmitInquiry) {
      await onSubmitInquiry({
        clientName: name || 'Contact Us Inquiry',
        phone,
        email,
        pumpName: roLocation || 'Retail Fuel Station',
        categoryName: requirement,
        title: `Contact Form Inquiry: ${requirement}`,
        description: `Contact: ${name} (${phone}, ${email}). Location: ${roLocation}. Note: ${notes}`,
        priority: 'MEDIUM',
        status: 'NEW'
      });
    }

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative border border-slate-200 max-h-[90vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <BPWLogo variant="light-bg" size="sm" subBrand="main" />
          <div>
            <h3 className="text-xl font-extrabold text-[#0F2B48]">
              Contact Bharat PetroWork
            </h3>
            <p className="text-xs text-slate-500">
              National Infrastructure & Field Engineering Helpdesk
            </p>
          </div>
        </div>

        {submitted ? (
          <div className="p-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
            <h4 className="text-lg font-extrabold text-emerald-900">Thank You! Message Received</h4>
            <p className="text-xs text-emerald-700">
              Our regional petroleum project engineer will contact you directly within 2 business hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rajesh Meena"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#0F2B48] focus:outline-none text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Contact *</label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#0F2B48] focus:outline-none text-slate-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="name@petrohub.in"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#0F2B48] focus:outline-none text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Station / City Location</label>
                <input
                  type="text"
                  placeholder="e.g. NH-48 Kotputli, Rajasthan"
                  value={roLocation}
                  onChange={e => setRoLocation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#0F2B48] focus:outline-none text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Service / Project Requirement</label>
              <select
                value={requirement}
                onChange={e => setRequirement(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#0F2B48] focus:outline-none bg-white text-slate-900"
              >
                <option>New Petrol Pump Infrastructure Development</option>
                <option>Civil Works & Canopy Installation</option>
                <option>Mechanical & Piping Systems</option>
                <option>Underground Tank Rehabilitation & Lining</option>
                <option>Dispenser Calibration & Electronic Maintenance</option>
                <option>Fire Safety System & PESO Audit</option>
                <option>Annual Maintenance Contract (AMC)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Project Details or Inquiry</label>
              <textarea
                rows={3}
                placeholder="Describe your site requirements, timeline, or scope of work..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#0F2B48] focus:outline-none text-slate-900"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-[#E55812]" />
                <span>Helpline: +91 1800-PETRO-WORK</span>
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-[#E55812] hover:bg-[#D9480F] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Inquiry</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
