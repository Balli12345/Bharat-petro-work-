import React from 'react';
import ustDiagramImg from '../../assets/images/ust_diagram_1789940678051.jpg';
import mobileVanImg from '../../assets/images/mobile_van_1789940690855.jpg';

interface CoreServiceItem {
  id: string;
  title: string;
  description: string;
  servicesInclude?: string[];
  bulletPoints?: string[];
  imageUrl: string;
  alt: string;
}

const CORE_SERVICES_DATA: CoreServiceItem[] = [
  {
    id: 'pipeline-maint',
    title: 'Pipeline Maintenance & Repair',
    description:
      'Reliable pipeline maintenance and repair services for safe and efficient fuel flow operations.',
    servicesInclude: [
      'Leak Detection & Inspection',
      'Pipeline Repair & Replacement',
      'Pressure Testing & Safety Checks'
    ],
    imageUrl:
      'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=700&q=80',
    alt: 'Underground fuel pipeline valve pit inspection'
  },
  {
    id: 'dispenser-services',
    title: 'Fuel Dispenser Services',
    description:
      'Professional fuel dispenser repair and maintenance solutions for smooth and accurate performance.',
    servicesInclude: [
      'Repair & Maintenance',
      'Calibration & Accuracy Check',
      'Electronic & Mechanical Fault Solutions'
    ],
    imageUrl:
      'https://images.unsplash.com/photo-1527018607637-02363bc8063a?auto=format&fit=crop&w=700&q=80',
    alt: 'Multi-product fuel dispenser nozzles'
  },
  {
    id: 'storage-tank-services',
    title: 'Storage Tank Services',
    description:
      'Complete storage tank solutions focused on safety, durability, and performance.',
    servicesInclude: [
      'Tank Cleaning',
      'Leak Testing & Inspection',
      'Tank Repair & Maintenance'
    ],
    imageUrl:
      'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=700&q=80',
    alt: 'Large industrial petroleum storage tank farm'
  },
  {
    id: 'mobile-van-support',
    title: 'Mobile Service Van Support',
    description:
      'Fast and efficient on-site maintenance support with fully equipped mobile service vans.',
    servicesInclude: [
      'On-Site Support',
      'Emergency Maintenance',
      'Inspection & Repair Services'
    ],
    imageUrl: mobileVanImg,
    alt: 'Bharat PetroWork mobile service and delivery van'
  },
  {
    id: 'site-maintenance',
    title: 'Complete Maintenance Solutions at Your Site',
    description:
      'End-to-end maintenance services for fuel systems and industrial infrastructure.',
    servicesInclude: [
      'Preventive Maintenance',
      'Equipment Inspection',
      'Repair & Support Services'
    ],
    imageUrl:
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=700&q=80',
    alt: 'Field engineers in safety vests inspecting site equipment'
  },
  {
    id: 'ust-rehab',
    title: 'Underground Tank Rehabilitation System',
    description:
      'Eliminates the need for complete tank replacement with major savings in excavation and civil work.',
    bulletPoints: [
      'Major savings in excavation and civil work',
      'Leak prevention and protection',
      'Groundwater safety and environmental protection',
      'Extends tank operational life by 20–30 years'
    ],
    imageUrl: ustDiagramImg,
    alt: 'UST Monitoring System and underground tank rehabilitation schematic diagram'
  }
];

export const CoreServicesSection: React.FC = () => {
  return (
    <section id="our-service-core" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1E293B] tracking-tight">
            Our Service Core
          </h2>
        </div>

        {/* 6 Cards with Orange Accent Border */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {CORE_SERVICES_DATA.map(service => (
            <div
              key={service.id}
              className="bg-white rounded-2xl border-2 border-[#E55812] overflow-hidden p-5 sm:p-6 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Image */}
                <div className="w-full h-48 sm:h-52 rounded-xl overflow-hidden mb-4 bg-slate-100 border border-slate-100">
                  <img
                    src={service.imageUrl}
                    alt={service.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                </div>

                {/* Title */}
                <h3 className="text-lg sm:text-xl font-extrabold text-[#1E293B] mb-2.5">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-slate-600 text-xs sm:text-[13px] leading-relaxed mb-3 font-normal">
                  {service.description}
                </p>

                {/* Services Include List */}
                {service.servicesInclude && service.servicesInclude.length > 0 && (
                  <div className="pt-2">
                    <div className="text-xs font-bold text-slate-800 mb-1.5">
                      Services Include:
                    </div>
                    <ul className="space-y-1">
                      {service.servicesInclude.map((item, idx) => (
                        <li
                          key={idx}
                          className="text-xs text-slate-600 flex items-center gap-1.5"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-[#E55812] shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Bullet Points (for Tank Rehab) */}
                {service.bulletPoints && service.bulletPoints.length > 0 && (
                  <ul className="space-y-1 pt-1">
                    {service.bulletPoints.map((item, idx) => (
                      <li
                        key={idx}
                        className="text-xs text-slate-600 flex items-center gap-1.5"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
