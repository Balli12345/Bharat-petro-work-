import React from 'react';
import { X, Award, ShieldCheck, CheckCircle2, Calendar } from 'lucide-react';
import { BPWLogo } from '../brand/BPWLogo';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative border border-slate-200 max-h-[90vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <BPWLogo variant="light-bg" size="sm" subBrand="main" />
          <div>
            <h3 className="text-xl font-extrabold text-[#0F2B48]">
              Our History & Legacy
            </h3>
            <p className="text-xs text-slate-500">
              Bharat PetroWork — Engineering Excellence Since 2014
            </p>
          </div>
        </div>

        <div className="space-y-6 text-sm text-slate-600 leading-relaxed">
          <p>
            Founded in Rajasthan and now operating nationwide, <strong className="text-[#0F2B48]">Bharat PetroWork</strong> began as a specialized petroleum mechanical contractor focusing on hazardous zone piping and underground tank safety. Over the past decade, we have expanded to become India's leading comprehensive petroleum infrastructure company.
          </p>

          <div className="border-l-2 border-[#E55812] pl-4 space-y-4 my-4">
            <div className="relative">
              <div className="text-xs font-bold text-[#E55812]">2014 — Foundation</div>
              <div className="text-xs font-bold text-slate-800">Mechanical Contracting & Forecourt Erection</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Pioneered high-accuracy dispenser alignment and double-wall electrofusion piping across northwest highway networks.
              </p>
            </div>

            <div className="relative">
              <div className="text-xs font-bold text-[#E55812]">2018 — PESO & OISD Certification</div>
              <div className="text-xs font-bold text-slate-800">Turnkey Civil, Tank Rehabilitation & Safety</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Introduced non-excavation ultrasonic internal tank lining and certified hazardous area FLP electrical systems.
              </p>
            </div>

            <div className="relative">
              <div className="text-xs font-bold text-[#E55812]">2022 — Pan-India Fleet & Rapid SLAs</div>
              <div className="text-xs font-bold text-slate-800">Mobile Service Vans & 24/7 Breakdown Desk</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Deployed GPS-tracked mobile service vans with 45-minute breakdown response across retail outlet networks.
              </p>
            </div>

            <div className="relative">
              <div className="text-xs font-bold text-[#E55812]">2026 — Unified Digital Ecosystem</div>
              <div className="text-xs font-bold text-slate-800">Pump Mitra, E-Market & BPW Academy</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Seamless digital platform integrating equipment ordering, certified petroleum technician training, and real-time dealer ticket management.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-center">
            <div>
              <div className="text-2xl font-extrabold text-[#E55812] font-mono">100+</div>
              <div className="text-[11px] font-semibold text-slate-700">Turnkey Projects</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-[#0F2B48] font-mono">10+</div>
              <div className="text-[11px] font-semibold text-slate-700">Years Experience</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-emerald-600 font-mono">24/7</div>
              <div className="text-[11px] font-semibold text-slate-700">Support Desk</div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-[#0F2B48] hover:bg-[#1A4068] text-white font-bold text-xs transition cursor-pointer"
          >
            Close Overview
          </button>
        </div>
      </div>
    </div>
  );
};
