import React from 'react';

interface IndustryItem {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  alt: string;
}

const INDUSTRIES_DATA: IndustryItem[] = [
  {
    id: 'petrol-pumps',
    title: 'Petrol Pumps',
    description:
      'We provide complete construction, installation, and maintenance services for petrol pumps, ensuring smooth operations, durability, and full compliance with industry standards.',
    imageUrl:
      'https://images.unsplash.com/photo-1527018607637-02363bc8063a?auto=format&fit=crop&w=700&q=80',
    alt: 'Multi-product fuel dispenser nozzles'
  },
  {
    id: 'fuel-storage',
    title: 'Fuel Storage Facilities',
    description:
      'Our team designs and develops safe and efficient fuel storage systems, including underground and above-ground tanks, ensuring proper handling, storage, and environmental safety.',
    imageUrl:
      'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=700&q=80',
    alt: 'Above-ground cylindrical fuel storage tanks'
  },
  {
    id: 'oil-terminals',
    title: 'Oil Terminals',
    description:
      'We support large-scale oil terminals with advanced infrastructure solutions, focusing on high-capacity storage, distribution systems, and safety compliance.',
    imageUrl:
      'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=700&q=80',
    alt: 'Coastal oil shipping terminal and depot'
  },
  {
    id: 'fuel-transport',
    title: 'Fuel Transport Companies',
    description:
      'We assist fuel transport businesses with reliable infrastructure and systems that ensure safe fuel handling, transfer, and operational efficiency.',
    imageUrl:
      'https://images.unsplash.com/photo-1545459720-aac8509eb02c?auto=format&fit=crop&w=700&q=80',
    alt: 'Highway fuel station illuminated at night with transport fleet'
  },
  {
    id: 'industrial-systems',
    title: 'Industrial Fuel Systems',
    description:
      'We develop customized fuel systems for industrial use, enabling seamless fuel supply and integration with various industrial operations.',
    imageUrl:
      'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=700&q=80',
    alt: 'Industrial refinery fuel storage tanks and piping skids'
  },
  {
    id: 'major-oil-companies',
    title: 'Major Oil Companies We Work With',
    description:
      'Bharat Petrowork executes projects in accordance with the strict guidelines and standards set by leading oil marketing companies in India. Our work aligns with the requirements of:',
    imageUrl:
      'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=700&q=80',
    alt: 'Modern corporate fuel distribution center and skyline'
  },
  {
    id: 'iocl',
    title: 'Indian Oil Corporation',
    description:
      "We follow industry-approved standards to deliver high-quality infrastructure that meets the expectations of India's largest oil company.",
    imageUrl:
      'https://images.unsplash.com/photo-1516199423452-525273d5b5e4?auto=format&fit=crop&w=700&q=80',
    alt: 'Offshore oil drilling rig platform at golden hour'
  },
  {
    id: 'bpcl',
    title: 'Bharat Petroleum',
    description:
      "Our solutions are designed to comply with Bharat Petroleum's technical and safety norms, ensuring reliable and efficient fuel station operations.",
    imageUrl:
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=80',
    alt: 'Petroleum refinery and petrochemical processing plant'
  }
];

export const IndustriesSection: React.FC = () => {
  return (
    <section id="industries-serve" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1E293B] tracking-tight">
            Industries We Serve
          </h2>
        </div>

        {/* 8 Cards in 4x2 Grid with Red/Orange Accent Border */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {INDUSTRIES_DATA.map(item => (
            <div
              key={item.id}
              className="bg-white rounded-2xl border-2 border-[#E55812] overflow-hidden p-5 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Thumbnail Image */}
                <div className="w-full h-44 rounded-xl overflow-hidden mb-4 bg-slate-100">
                  <img
                    src={item.imageUrl}
                    alt={item.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                </div>

                {/* Card Title */}
                <h3 className="text-base font-extrabold text-[#1E293B] mb-2 leading-snug">
                  {item.title}
                </h3>

                {/* Card Description */}
                <p className="text-slate-600 text-xs leading-relaxed font-normal">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
