import React from 'react';

interface ServiceItem {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  alt: string;
}

const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'civil-works',
    title: 'Civil Works',
    description:
      'We offer complete civil construction solutions including site development, foundation work, canopy installation, drainage systems, road construction, and building structures such as offices and restrooms, ensuring a strong and durable base for fuel stations.',
    imageUrl:
      'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f7?auto=format&fit=crop&w=700&q=80',
    alt: 'Civil construction site with crane and steel canopy foundation'
  },
  {
    id: 'mechanical-works',
    title: 'Mechanical Works',
    description:
      'Our mechanical services include installation of underground and above-ground fuel storage tanks, pipeline systems, fuel dispensers, tank cleaning, and vapor recovery systems to ensure efficient and safe fuel operations.',
    imageUrl:
      'https://images.unsplash.com/photo-1527018607637-02363bc8063a?auto=format&fit=crop&w=700&q=80',
    alt: 'Multi-product fuel dispenser nozzles and manifold'
  },
  {
    id: 'electrical-works',
    title: 'Electrical Works',
    description:
      'We provide comprehensive electrical solutions including wiring, panel installation, lighting systems, high mast installation, earthing, DG sets, power backup, and advanced automation systems for smooth operations.',
    imageUrl:
      'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=700&q=80',
    alt: 'Electrician working on industrial electrical switchboard panel'
  },
  {
    id: 'fire-safety',
    title: 'Fire & Safety Systems',
    description:
      'Safety is our priority. We install complete firefighting systems, fire extinguishers, and conduct safety audits to ensure compliance with industry safety standards.',
    imageUrl:
      'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=700&q=80',
    alt: 'Fire extinguisher safety inspection and audit'
  },
  {
    id: 'om-services',
    title: 'Operation & Maintenance (O&M)',
    description:
      'We provide ongoing support through routine inspections, servicing, emergency repairs, and Annual Maintenance Contracts (AMC) to ensure uninterrupted performance of petrol pumps.',
    imageUrl:
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=700&q=80',
    alt: 'Engineer inspecting industrial pipe pump and forecourt machinery'
  },
  {
    id: 'tank-rehab',
    title: 'Tank Rehabilitation Work Services',
    description:
      'Bharat Petrowork Fuel Infrastructure Rehabilitation & Environmental Protection Engineering Company. Bharat Petrowork is an advanced technical and engineering service company in India specializing in fuel infrastructure rehabilitation, safety enhancement, environmental protection, and modern tank engineering solutions.',
    imageUrl:
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=80',
    alt: 'Underground fuel storage tank rehabilitation engineering'
  }
];

interface OurServicesSectionProps {
  onSelectService?: (serviceTitle: string) => void;
}

export const OurServicesSection: React.FC<OurServicesSectionProps> = ({ onSelectService }) => {
  return (
    <section id="our-services" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1E293B] tracking-tight">
            Our Services
          </h2>
        </div>

        {/* 6 Grid Cards with Red/Orange Accent Border */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {SERVICES_DATA.map(service => (
            <div
              key={service.id}
              className="bg-white rounded-2xl border-2 border-[#E55812] overflow-hidden p-5 sm:p-6 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Image Container */}
                <div className="w-full h-48 sm:h-52 rounded-xl overflow-hidden mb-4 bg-slate-100">
                  <img
                    src={service.imageUrl}
                    alt={service.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                </div>

                {/* Title */}
                <h3 className="text-lg sm:text-xl font-extrabold text-[#1E293B] mb-2.5">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-slate-600 text-xs sm:text-[13px] leading-relaxed font-normal">
                  {service.description}
                </p>
              </div>

              {onSelectService && (
                <div className="pt-4 mt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => onSelectService(service.title)}
                    className="text-xs font-bold text-[#E55812] hover:text-[#0F2B48] transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>Request Service Consultation</span>
                    <span>→</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
