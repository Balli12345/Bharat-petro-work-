import React from 'react';

interface ProcessStep {
  id: string;
  title: string;
  description: string;
  renderIcon: () => React.ReactNode;
}

const PROCESS_STEPS: ProcessStep[] = [
  {
    id: 'planning',
    title: 'Planning &\nConsultation',
    description: 'Understanding client requirements and site conditions',
    renderIcon: () => (
      <svg className="w-16 h-16 mx-auto" viewBox="0 0 64 64" fill="none">
        {/* Presentation Board & People */}
        <rect x="18" y="10" width="36" height="26" rx="3" fill="#EBF4FF" stroke="#3B82F6" strokeWidth="2" />
        <path d="M24 28L32 20L38 25L48 16" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="48" cy="16" r="2.5" fill="#EF4444" />
        <rect x="24" y="30" width="4" height="3" fill="#93C5FD" />
        <rect x="30" y="27" width="4" height="6" fill="#60A5FA" />
        <rect x="36" y="24" width="4" height="9" fill="#3B82F6" />
        <path d="M36 36V44M30 44H42" stroke="#64748B" strokeWidth="2" strokeLinecap="round" />
        {/* People consulting */}
        <circle cx="14" cy="22" r="4" fill="#FBBF24" />
        <path d="M8 38C8 33 11 30 14 30C17 30 20 33 20 38" fill="#1E40AF" />
        <circle cx="16" cy="46" r="3.5" fill="#FBBF24" />
        <path d="M11 58C11 54 13.5 51 16 51C18.5 51 21 54 21 58" fill="#DC2626" />
      </svg>
    )
  },
  {
    id: 'design',
    title: 'Design &\nEngineering',
    description: 'Creating precise layouts and technical plans',
    renderIcon: () => (
      <svg className="w-16 h-16 mx-auto" viewBox="0 0 64 64" fill="none">
        {/* Blueprint & Compass / Tools */}
        <rect x="10" y="14" width="44" height="34" rx="4" fill="#FFFBEB" stroke="#F59E0B" strokeWidth="2" />
        <path d="M16 22H48M16 30H36M16 38H42" stroke="#FBBF24" strokeWidth="2" strokeLinecap="round" />
        {/* Colorful gear and ruler */}
        <circle cx="42" cy="32" r="9" fill="#FEF3C7" stroke="#EA580C" strokeWidth="2" />
        <path d="M42 27V37M37 32H47" stroke="#EA580C" strokeWidth="2" strokeLinecap="round" />
        <rect x="22" y="38" width="24" height="12" rx="2" fill="#38BDF8" transform="rotate(-15 22 38)" />
        <circle cx="28" cy="20" r="3" fill="#10B981" />
        <circle cx="36" cy="18" r="2.5" fill="#EF4444" />
      </svg>
    )
  },
  {
    id: 'execution',
    title: 'Execution &\nInstallation',
    description: 'Implementing the project with accuracy',
    renderIcon: () => (
      <svg className="w-16 h-16 mx-auto" viewBox="0 0 64 64" fill="none">
        {/* Engineers with safety helmets & site work */}
        <rect x="14" y="24" width="36" height="24" rx="3" fill="#EEF2FF" stroke="#6366F1" strokeWidth="2" />
        <path d="M22 34L28 40L42 26" stroke="#4F46E5" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="24" cy="14" r="5" fill="#F59E0B" />
        <path d="M19 14C19 11 21 9 24 9C27 9 29 11 29 14H19Z" fill="#F97316" />
        <circle cx="40" cy="14" r="5" fill="#F59E0B" />
        <path d="M35 14C35 11 37 9 40 9C43 9 45 11 45 14H35Z" fill="#3B82F6" />
        {/* Brick / structure */}
        <rect x="18" y="44" width="8" height="6" fill="#EA580C" />
        <rect x="28" y="44" width="8" height="6" fill="#F97316" />
        <rect x="38" y="44" width="8" height="6" fill="#FB923C" />
      </svg>
    )
  },
  {
    id: 'testing',
    title: 'Testing &\nCompliance',
    description: 'Ensuring all systems meet safety standards',
    renderIcon: () => (
      <svg className="w-16 h-16 mx-auto" viewBox="0 0 64 64" fill="none">
        {/* Clipboard with Red Check Badge */}
        <rect x="14" y="10" width="36" height="46" rx="4" fill="#FEF2F2" stroke="#EF4444" strokeWidth="2" />
        <rect x="24" y="6" width="16" height="7" rx="2" fill="#DC2626" />
        <path d="M22 24H42M22 32H38M22 40H32" stroke="#FCA5A5" strokeWidth="2.5" strokeLinecap="round" />
        {/* Verified Badge */}
        <circle cx="26" cy="24" r="7" fill="#EF4444" />
        <path d="M23 24L25 26L29 22" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    )
  },
  {
    id: 'handover',
    title: 'Handover &\nSupport',
    description: 'Delivering a fully operational site with ongoing support',
    renderIcon: () => (
      <svg className="w-16 h-16 mx-auto" viewBox="0 0 64 64" fill="none">
        {/* Certificate Medal & Ribbon */}
        <circle cx="32" cy="26" r="14" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="2.5" />
        <circle cx="32" cy="26" r="10" fill="#FDE047" />
        <path d="M28 26L31 29L36 23" stroke="#B45309" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        {/* Hanging Ribbons */}
        <path d="M26 38L22 52L29 48L32 52L30 38" fill="#EC4899" />
        <path d="M38 38L42 52L35 48L32 52L34 38" fill="#F43F5E" />
        {/* Sparkles */}
        <circle cx="16" cy="18" r="2" fill="#F59E0B" />
        <circle cx="48" cy="20" r="2.5" fill="#EC4899" />
        <circle cx="46" cy="38" r="1.5" fill="#3B82F6" />
      </svg>
    )
  }
];

export const WorkProcessSection: React.FC = () => {
  return (
    <section id="work-process" className="py-16 sm:py-20 bg-[#F0F7FD] border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1E293B] tracking-tight">
            Work Process
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-3 font-normal">
            We follow a streamlined and efficient process to ensure quality outcomes:
          </p>
        </div>

        {/* 5 Process Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 sm:gap-6">
          {PROCESS_STEPS.map(step => (
            <div
              key={step.id}
              className="bg-white rounded-2xl border border-slate-200/90 p-6 text-center shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Visual Icon Illustration */}
                <div className="h-20 flex items-center justify-center mb-4">
                  {step.renderIcon()}
                </div>

                {/* Step Title */}
                <h3 className="text-sm sm:text-base font-extrabold text-[#1E293B] whitespace-pre-line leading-snug mb-3">
                  {step.title}
                </h3>

                {/* Step Description */}
                <p className="text-slate-500 text-xs sm:text-[13px] leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
