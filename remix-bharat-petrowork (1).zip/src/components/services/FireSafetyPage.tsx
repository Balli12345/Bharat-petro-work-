import React from 'react';

export const FireSafetyPage: React.FC = () => {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <h1 className="text-4xl font-extrabold text-[#0F2B48] mb-6">Fire & Safety Systems</h1>
        <p className="text-slate-600">Details about our fire & safety systems services...</p>
      </div>
    </div>
  );
};
