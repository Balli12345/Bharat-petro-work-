import { DeliveryConsignment, TrafficCondition, DeliveryStatus } from '../types';

export interface ETASimulationOptions {
  distanceDeltaKm?: number;
  forcedTrafficCondition?: TrafficCondition;
  forcedSpeedKmph?: number;
  customAlert?: string;
  now?: Date;
}

const TRAFFIC_SCENARIOS: Array<{
  condition: TrafficCondition;
  speedRange: [number, number]; // km/h
  delayRange: [number, number]; // minutes
  alerts: string[];
}> = [
  {
    condition: 'CLEAR',
    speedRange: [65, 78],
    delayRange: [0, 4],
    alerts: [
      'Green corridor: Optimal highway speed on NH-48 Expressway.',
      'Express lane clear: Smooth transit with no active toll slowdowns.',
      'Free flowing freight transit corridor towards destination.'
    ]
  },
  {
    condition: 'MODERATE',
    speedRange: [42, 58],
    delayRange: [6, 14],
    alerts: [
      'Moderate traffic approaching Dharuhera toll plaza (+8 mins).',
      'Lane merge and industrial freight movement causing minor slowdown (+11 mins).',
      'Intermittent highway queue near Bilaspur flyover (+9 mins).'
    ]
  },
  {
    condition: 'HEAVY',
    speedRange: [22, 38],
    delayRange: [18, 28],
    alerts: [
      'Heavy freight density and monsoon road maintenance on outer corridor (+22 mins).',
      'Commercial vehicle queue at state border toll checkpoint (+25 mins).',
      'Slow moving traffic due to single-lane diversion near Bawal (+19 mins).'
    ]
  },
  {
    condition: 'CONGESTED',
    speedRange: [12, 22],
    delayRange: [30, 45],
    alerts: [
      'Severe bottleneck: Heavy multi-axle freight jam at flyover intersection (+36 mins).',
      'Expressway diversion in effect: High vehicular density (+40 mins).'
    ]
  }
];

function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getCorridorWaypoint(remainingKm: number, defaultCity: string): string {
  if (remainingKm <= 0) return 'Highway Petro Hub Forecourt Yard';
  if (remainingKm < 8) return 'Kotputli Forecourt Approach (NH-48 KM 142)';
  if (remainingKm < 25) return 'Kotputli Bypass Milepost 18';
  if (remainingKm < 45) return 'Rewari - Bawal Industrial Toll Link';
  if (remainingKm < 65) return 'NH-48 Dharuhera Express Corridor';
  if (remainingKm < 85) return 'Palwal - Mathura Inter-State Corridor (NH-19)';
  return defaultCity;
}

/**
 * Updates an individual consignment's ETA and telemetry based on mock real-time traffic
 * updates or distance changes.
 */
export function updateConsignmentETA(
  consignment: DeliveryConsignment,
  options?: ETASimulationOptions
): DeliveryConsignment {
  // If shipment is not in an active transit state, maintain its terminal status
  if (consignment.status === 'FORECOURT_ARRIVED') {
    return {
      ...consignment,
      eta: 'Arrived at destination site',
      remainingDistanceKm: 0,
      currentSpeedKmph: 0,
      trafficCondition: 'CLEAR',
      trafficDelayMinutes: 0,
      trafficAlert: 'Consignment arrived at forecourt yard. Ready for offloading.',
      lastTrafficUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
  }

  if (consignment.status === 'UNLOADED_INSPECTED') {
    return {
      ...consignment,
      eta: 'Offloaded & Inspected',
      remainingDistanceKm: 0,
      currentSpeedKmph: 0,
      trafficCondition: 'CLEAR',
      trafficDelayMinutes: 0,
      lastTrafficUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
  }

  if (consignment.status === 'DELIVERED_POD') {
    return {
      ...consignment,
      eta: 'Delivered',
      remainingDistanceKm: 0,
      currentSpeedKmph: 0,
      trafficCondition: 'CLEAR',
      trafficDelayMinutes: 0,
      trafficAlert: 'Digital POD completed. Consignment finalized.',
      lastTrafficUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
  }

  if (consignment.status === 'PENDING_DISPATCH') {
    return {
      ...consignment,
      eta: 'Awaiting Fleet Departure',
      remainingDistanceKm: consignment.remainingDistanceKm ?? 95,
      currentSpeedKmph: 0,
      trafficCondition: 'CLEAR',
      trafficDelayMinutes: 0,
      trafficAlert: 'Shipment staged in warehouse yard; awaiting dispatch authorization.',
      lastTrafficUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
  }

  // Active in-transit or dispatched status
  const currentDistance = consignment.remainingDistanceKm ?? 84;
  
  // Calculate simulated distance change
  const distanceDelta = options?.distanceDeltaKm !== undefined 
    ? options.distanceDeltaKm 
    : Number((Math.random() * 2.8 + 1.2).toFixed(1)); // progress by 1.2 to 4.0 km per tick

  const nextDistance = Math.max(0, Number((currentDistance - distanceDelta).toFixed(1)));

  // Check if consignment arrived at destination during this update
  if (nextDistance <= 0) {
    const updatedStatus: DeliveryStatus = 'FORECOURT_ARRIVED';
    return {
      ...consignment,
      status: updatedStatus,
      currentCity: 'Forecourt Retail Outlet Yard',
      eta: 'Arrived at destination site',
      remainingDistanceKm: 0,
      currentSpeedKmph: 0,
      trafficCondition: 'CLEAR',
      trafficDelayMinutes: 0,
      trafficAlert: 'Vehicle has reached the retail outlet forecourt yard. Driver completing arrival protocol.',
      lastTrafficUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
  }

  // Determine traffic scenario
  let scenario = TRAFFIC_SCENARIOS[0]; // default CLEAR
  if (options?.forcedTrafficCondition) {
    scenario = TRAFFIC_SCENARIOS.find(s => s.condition === options.forcedTrafficCondition) || TRAFFIC_SCENARIOS[0];
  } else {
    // Probabilistic distribution based on real highway transit (60% Clear/Moderate, 30% Heavy, 10% Congested)
    const roll = Math.random();
    if (roll < 0.45) {
      scenario = TRAFFIC_SCENARIOS[0]; // CLEAR
    } else if (roll < 0.78) {
      scenario = TRAFFIC_SCENARIOS[1]; // MODERATE
    } else if (roll < 0.94) {
      scenario = TRAFFIC_SCENARIOS[2]; // HEAVY
    } else {
      scenario = TRAFFIC_SCENARIOS[3]; // CONGESTED
    }
  }

  const speedKmph = options?.forcedSpeedKmph ?? getRandomInt(scenario.speedRange[0], scenario.speedRange[1]);
  const delayMinutes = getRandomInt(scenario.delayRange[0], scenario.delayRange[1]);
  const alert = options?.customAlert ?? scenario.alerts[Math.floor(Math.random() * scenario.alerts.length)];

  // Calculate dynamic travel duration
  const effectiveSpeed = Math.max(15, speedKmph);
  const baseTravelMinutes = Math.round((nextDistance / effectiveSpeed) * 60);
  const totalRemainingMinutes = Math.max(2, baseTravelMinutes + delayMinutes);

  // Compute calculated arrival time
  const currentTime = options?.now || new Date();
  const arrivalDate = new Date(currentTime.getTime() + totalRemainingMinutes * 60 * 1000);
  
  const arrivalTimeString = arrivalDate.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  const hours = Math.floor(totalRemainingMinutes / 60);
  const minutes = totalRemainingMinutes % 60;
  const timeSpanString = hours > 0 
    ? `${hours} hr ${minutes > 0 ? `${minutes} mins` : ''}`.trim()
    : `${minutes} mins`;

  const trafficLabel = scenario.condition !== 'CLEAR' ? ` • ${scenario.condition} Traffic` : '';
  const calculatedEta = `Today, ${arrivalTimeString} (${timeSpanString}${trafficLabel})`;
  const updatedCity = getCorridorWaypoint(nextDistance, consignment.currentCity);

  return {
    ...consignment,
    remainingDistanceKm: nextDistance,
    currentSpeedKmph: speedKmph,
    trafficCondition: scenario.condition,
    trafficDelayMinutes: delayMinutes,
    trafficAlert: alert,
    currentCity: updatedCity,
    eta: calculatedEta,
    lastTrafficUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  };
}

/**
 * Periodically updates all active consignments' ETAs based on mock real-time traffic
 * updates or distance changes.
 */
export function periodicallyUpdateConsignmentsETA(
  consignments: DeliveryConsignment[],
  options?: ETASimulationOptions
): DeliveryConsignment[] {
  return consignments.map(consignment => {
    // Only update active in-transit shipments
    if (consignment.status === 'IN_TRANSIT' || consignment.status === 'DISPATCHED') {
      return updateConsignmentETA(consignment, options);
    }
    return consignment;
  });
}
